package dev.arnoldsemase.calculator.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.arnoldsemase.calculator.ui.components.ArnoldLogo
import dev.arnoldsemase.calculator.ui.theme.Arnold
import dev.arnoldsemase.calculator.ui.theme.ArnoldFonts
import kotlinx.coroutines.launch

/** Shown right after the system splash: the logo settles in, then the wordmark fades up. */
@Composable
fun SplashOverlay() {
    val c = Arnold.colors
    val logo = remember { Animatable(0f) }
    val text = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { logo.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
        launch {
            kotlinx.coroutines.delay(300)
            text.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
        }
    }

    Box(Modifier.fillMaxSize().background(c.background)) {
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ArnoldLogo(
                size = 112.dp,
                modifier = Modifier
                    .graphicsLayer {
                        val s = 0.82f + 0.18f * logo.value
                        scaleX = s
                        scaleY = s
                        alpha = logo.value
                    }
                    .shadow(
                        elevation = 24.dp,
                        shape = RoundedCornerShape(34.dp),
                        ambientColor = c.accent.copy(alpha = 0.35f),
                        spotColor = c.accent.copy(alpha = 0.5f),
                    ),
            )
            Spacer(Modifier.height(28.dp))
            Column(
                Modifier.graphicsLayer {
                    alpha = text.value
                    translationY = (1f - text.value) * 16.dp.toPx()
                },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "Arnold",
                    color = c.text,
                    fontFamily = ArnoldFonts.Display,
                    fontWeight = FontWeight.Bold,
                    fontSize = 34.sp,
                )
                Text(
                    text = "CALCULATOR",
                    color = c.textSecondary,
                    fontFamily = ArnoldFonts.Display,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp,
                    letterSpacing = 5.sp,
                )
            }
        }
        Text(
            text = "Arnold OS Apps",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 32.dp)
                .graphicsLayer { alpha = text.value },
            color = c.textSecondary,
            fontSize = 12.sp,
            letterSpacing = 1.sp,
        )
    }
}
